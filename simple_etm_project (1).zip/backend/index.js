const express = require('express');
const app = express();
app.use(express.json());

const events = {};
let nextId = 1;

// Create event
app.post('/api/events', (req, res) => {
  const { name, total } = req.body;
  if (!name || !total) return res.status(400).json({ error: "Invalid data" });
  const id = String(nextId++);
  events[id] = { id, name, total, sold: 0 };
  res.json(events[id]);
});

// List
app.get('/api/events', (req, res) => res.json(Object.values(events)));

// Buy
app.post('/api/events/:id/buy', (req, res) => {
  const e = events[req.params.id];
  if (!e) return res.status(404).json({ error: "Not found" });
  if (e.sold >= e.total) return res.status(400).json({ error: "Sold out" });
  e.sold++;
  res.json(e);
});

// Metrics
app.get('/metrics', (req, res) => {
  const totalEvents = Object.keys(events).length;
  const totalSold = Object.values(events).reduce((s,x)=>s+x.sold,0);
  res.set("Content-Type","text/plain");
  res.send(`etm_total_events ${totalEvents}
etm_total_sold ${totalSold}`);
});

app.listen(4000, ()=> console.log("Backend running on 4000"));
